import SwiftUI

struct DemoTransaction: Identifiable {
    let id = UUID()
    let name: String
    let detail: String
    let amount: Double
    let symbol: String
    let tint: Color
}

struct ContentView: View {
    @State private var showSend = false
    @State private var showAdd = false
    @State private var showActivity = false
    @State private var recipient = ""
    @State private var amountText = ""
    @State private var balance = 248.50
    @State private var note = ""
    @State private var notice = ""

    @State private var transactions: [DemoTransaction] = [
        DemoTransaction(name: "Jordan M.", detail: "Today · Demo payment", amount: -12.00, symbol: "person.fill", tint: .blue),
        DemoTransaction(name: "Lunch", detail: "Yesterday · Demo purchase", amount: -8.75, symbol: "fork.knife", tint: .orange),
        DemoTransaction(name: "Demo deposit", detail: "Oct 18 · Simulated", amount: 50.00, symbol: "plus", tint: Color(red: 0.0, green: 0.65, blue: 0.38))
    ]

    private let green = Color(red: 0.0, green: 0.72, blue: 0.42)

    var body: some View {
        NavigationStack {
            ZStack {
                Color(red: 0.96, green: 0.97, blue: 0.96).ignoresSafeArea()
                ScrollView(showsIndicators: false) {
                    VStack(alignment: .leading, spacing: 22) {
                        header
                        balanceCard
                        quickActions
                        activitySection
                        disclaimer
                    }
                    .padding(.horizontal, 20)
                    .padding(.top, 10)
                    .padding(.bottom, 28)
                }
            }
            .toolbar(.hidden, for: .navigationBar)
            .sheet(isPresented: $showSend) { paymentSheet(isSend: true) }
            .sheet(isPresented: $showAdd) { paymentSheet(isSend: false) }
            .sheet(isPresented: $showActivity) { activitySheet }
            .alert("Pocket Demo", isPresented: Binding(get: { !notice.isEmpty }, set: { if !$0 { notice = "" } })) {
                Button("OK", role: .cancel) { notice = "" }
            } message: { Text(notice) }
        }
        .tint(green)
    }

    private var header: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text("Good evening")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)
                Text("Pocket")
                    .font(.system(size: 32, weight: .bold, design: .rounded))
                    .foregroundStyle(Color.black.opacity(0.88))
            }
            Spacer()
            ZStack {
                Circle().fill(green).frame(width: 48, height: 48)
                Image(systemName: "person.fill").font(.system(size: 19, weight: .semibold)).foregroundStyle(.white)
            }
            .accessibilityLabel("Demo profile")
        }
    }

    private var balanceCard: some View {
        VStack(alignment: .leading, spacing: 15) {
            HStack {
                Label("DEMO BALANCE", systemImage: "sparkles")
                    .font(.caption.weight(.bold))
                    .tracking(1.1)
                    .foregroundStyle(.white.opacity(0.85))
                Spacer()
                Image(systemName: "ellipsis")
                    .font(.title3.weight(.bold))
                    .foregroundStyle(.white.opacity(0.85))
            }
            Text(balance, format: .currency(code: "USD"))
                .font(.system(size: 39, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
                .minimumScaleFactor(0.7)
                .lineLimit(1)
            HStack(spacing: 7) {
                Image(systemName: "info.circle.fill")
                Text("Simulated funds · No real money")
            }
            .font(.caption.weight(.medium))
            .foregroundStyle(.white.opacity(0.88))
        }
        .padding(22)
        .frame(maxWidth: .infinity, alignment: .leading)
        .background(LinearGradient(colors: [green, Color(red: 0.0, green: 0.52, blue: 0.31)], startPoint: .topLeading, endPoint: .bottomTrailing))
        .clipShape(RoundedRectangle(cornerRadius: 26, style: .continuous))
        .shadow(color: green.opacity(0.22), radius: 15, x: 0, y: 8)
    }

    private var quickActions: some View {
        HStack(spacing: 12) {
            actionButton("Send", icon: "arrow.up.right", color: green) { resetForm(); showSend = true }
            actionButton("Add money", icon: "plus", color: .black) { resetForm(); showAdd = true }
            actionButton("Activity", icon: "clock.arrow.circlepath", color: .black) { showActivity = true }
        }
    }

    private func actionButton(_ title: String, icon: String, color: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            VStack(spacing: 11) {
                Image(systemName: icon).font(.system(size: 20, weight: .bold)).foregroundStyle(.white)
                    .frame(width: 52, height: 52).background(color).clipShape(Circle())
                Text(title).font(.subheadline.weight(.semibold)).foregroundStyle(.primary).lineLimit(1).minimumScaleFactor(0.8)
            }
            .frame(maxWidth: .infinity)
            .padding(.vertical, 14)
            .background(.white)
            .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
        }
        .buttonStyle(.plain)
    }

    private var activitySection: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack {
                Text("Recent activity").font(.title3.weight(.bold))
                Spacer()
                Button("See all") { showActivity = true }.font(.subheadline.weight(.semibold))
            }
            if transactions.isEmpty {
                Text("Your demo activity will show up here.").font(.subheadline).foregroundStyle(.secondary).padding(.vertical, 12)
            } else {
                VStack(spacing: 0) {
                    ForEach(Array(transactions.prefix(4))) { item in
                        transactionRow(item)
                        if item.id != transactions.prefix(4).last?.id { Divider().padding(.leading, 60) }
                    }
                }
                .padding(.horizontal, 14)
                .background(.white)
                .clipShape(RoundedRectangle(cornerRadius: 20, style: .continuous))
            }
        }
    }

    private func transactionRow(_ item: DemoTransaction) -> some View {
        HStack(spacing: 12) {
            Image(systemName: item.symbol).font(.system(size: 17, weight: .semibold)).foregroundStyle(.white)
                .frame(width: 42, height: 42).background(item.tint).clipShape(Circle())
            VStack(alignment: .leading, spacing: 4) {
                Text(item.name).font(.subheadline.weight(.semibold)).foregroundStyle(.primary)
                Text(item.detail).font(.caption).foregroundStyle(.secondary)
            }
            Spacer(minLength: 8)
            Text(item.amount, format: .currency(code: "USD"))
                .font(.subheadline.weight(.bold)).foregroundStyle(.primary)
        }
        .padding(.vertical, 13)
    }

    private var disclaimer: some View {
        HStack(alignment: .top, spacing: 8) {
            Image(systemName: "info.circle.fill").foregroundStyle(green)
            Text("Pocket is an unofficial UI demo. Balances and transactions are simulated; no real payments or bank connections are supported.")
                .font(.caption).foregroundStyle(.secondary)
        }
        .padding(.horizontal, 2)
    }

    private func paymentSheet(isSend: Bool) -> some View {
        NavigationStack {
            Form {
                Section(isSend ? "Demo recipient" : "Demo deposit") {
                    if isSend {
                        TextField("Name or $cashtag (demo only)", text: $recipient)
                            .textInputAutocapitalization(.words)
                    }
                    TextField("Amount (USD)", text: $amountText)
                        .keyboardType(.decimalPad)
                    TextField("Note (optional)", text: $note)
                }
                Section {
                    Text(isSend ? "This only updates the local demo screen. It will not send money." : "This adds simulated funds only. No payment method is used.")
                        .font(.footnote).foregroundStyle(.secondary)
                }
                Section {
                    Button(isSend ? "Simulate send" : "Add demo funds") { performDemoTransaction(isSend: isSend) }
                        .fontWeight(.semibold)
                }
            }
            .navigationTitle(isSend ? "Send (Demo)" : "Add funds (Demo)")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Close") { isSend ? (showSend = false) : (showAdd = false) } } }
        }
        .presentationDetents([.medium, .large])
    }

    private var activitySheet: some View {
        NavigationStack {
            List {
                ForEach(transactions) { item in
                    transactionRow(item).listRowSeparator(.visible)
                }
            }
            .navigationTitle("Demo activity")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { showActivity = false } } }
        }
        .presentationDetents([.medium, .large])
    }

    private func resetForm() { recipient = ""; amountText = ""; note = "" }

    private func performDemoTransaction(isSend: Bool) {
        guard let amount = Double(amountText), amount > 0, amount.isFinite, amount <= 100_000 else {
            notice = "Enter a valid demo amount between $0.01 and $100,000."
            return
        }
        if isSend && recipient.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            notice = "Enter a demo recipient name. No real payment will be made."
            return
        }
        if isSend && amount > balance {
            notice = "That exceeds the simulated demo balance."
            return
        }
        balance += isSend ? -amount : amount
        let name = isSend ? recipient.trimmingCharacters(in: .whitespacesAndNewlines) : "Demo deposit"
        let detail = (isSend ? "Simulated send" : "Simulated deposit") + (note.isEmpty ? " · Just now" : " · \(note)")
        transactions.insert(DemoTransaction(name: name, detail: detail, amount: isSend ? -amount : amount, symbol: isSend ? "arrow.up.right" : "plus", tint: isSend ? .blue : green), at: 0)
        showSend = false
        showAdd = false
        notice = isSend ? "Demo send recorded locally. No money was sent." : "Demo funds added locally. No real money was added."
        resetForm()
    }
}
