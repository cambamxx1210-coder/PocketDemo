import SwiftUI

@main
struct PocketDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
