# Pocket Demo (SwiftUI)

A standalone iOS sample app with a green payment-wallet-inspired interface, a demo balance, recent activity, and local-only simulated send/deposit actions.

**Not Cash App.** This is an unofficial demo. It does not connect to a bank, process payments, or move real money. Demo transactions only change in-memory state and reset when the app restarts.

## Build on a Mac
1. Install Xcode from the Mac App Store.
2. Open `PocketDemo.xcodeproj` in Xcode.
3. Select the `PocketDemo` target, then choose a unique Bundle Identifier in Signing & Capabilities.
4. Connect your iPhone or select an iOS Simulator.
5. Select a development Team if installing on a physical iPhone, then press Run.
6. To create an IPA for your own device or distribution, use Product > Archive, then Distribute App. Apple signing and distribution requirements apply.

The uploaded Cash App Pay SDK is not included because this sample is intentionally standalone and uses simulated money only.
